package pl.symentis.bytecode.instrument;

public interface TestInterface {

	Integer testMethod(Integer i);

}
