package pl.symentis.bytecode.bytebuddy;

public class MyClass {

	@Override
	public String toString() {
		return "to moja class'a";
	}
	
	

}
