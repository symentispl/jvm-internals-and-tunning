package pl.symentis.jvminternals.bytecode;

public class HelloWorld {
	
	@SafeVarargs
	public static void main(String... args) {
		try {
			System.out.println("Hello");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
