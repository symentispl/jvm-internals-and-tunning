package pl.symentis.jvminternals.bytecode;

public interface Comparator {

	public String greaterThan(int a, int b);

}
